"""HEX-Bridge MCP server."""
