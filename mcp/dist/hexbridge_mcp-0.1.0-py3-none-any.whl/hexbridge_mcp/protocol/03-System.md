# 3. 系统管理命令 (0x00-0x0F)

## 命令码一览

| 命令码 | 名称 | 方向 | 说明 |
|:---|:---|:---|:---|
| `0x00` | PING | 双向 | 心跳检测 |
| `0x01` | GET_INFO | 请求-响应 | 获取设备信息 |
| `0x02` | GET_CONFIG | 请求-响应 | 读取设备配置 |
| `0x03` | SET_CONFIG | 请求-响应 | 写入设备配置 |
| `0x04` | RESET | 请求-响应 | 复位设备/通道 |
| `0x05` | FLOW_CONTROL | 双向 | 流量控制 |
| `0x06` | SYS_BOOT_EVENT | 设备 → 主机 | 系统启动与复位事件上报 |
| `0x07` | GET_TOPOLOGY | 请求-响应 | 获取硬件拓扑 (通道列表) |
| `0x08` | DEVICE_PROFILE | 请求-响应 | [功能开关、固定引脚及配置事务](17-Device-Profile.md) |
| `0x09-0x0F` | — | — | 保留 |

## 3.0 设备连接、识别与握手流程规范 (Handshake & Identification Flow)

当上位机 (MCP Server) 通过串口/USB 物理链路与设备建立连接时，应按照以下规范执行识别与连接确认：

1. **物理连接确认 (Connectivity Check)**：
   * 主机发送 `PING (0x00)` 请求。
   * 若收到格式合法、状态码为 `SUCCESS (0x00)` 的响应，说明底层通信链路正常，且对方设备在线。
2. **设备身份识别 (Identification)**：
   * 主机发送 `GET_INFO (0x01)` 请求。
   * 主机通过验证响应中的 `ModelID`（如 `"HXB1"`）来确认是否为目标硬件，验证 `ProtoVersion` (v2.0 对应 `0x02`) 确认协议版本兼容，并读取唯一的设备序列号 `SerialNum` 以在多设备共存时进行独立挂载。同时，可根据 `Capabilities` 支持的功能位图在 MCP Server 中动态开启/关闭外设工具子集。
3. **心跳与连接维持 (Heartbeat & Keep-Alive)**：
   * 主机在空闲状态下，应以周期性（如 `HeartbeatInterval`）发送 `PING` 维护连接心跳。如果连续 3 次心跳超时未响应，应判定设备已断开连接。

---

## 3.1 PING (0x00) — 心跳检测

用于检测设备是否在线，以及获取基础运行状态。

### 请求 (主机 → 设备)

载荷为空 (PayloadLen = 0)。

### 响应 (设备 → 主机)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | Status | u8 | 状态码 (0x00 = 成功) |
| 1-4 | Uptime | u32 | 设备运行时间（微秒） |
| 5 | Load | u8 | CPU 负载百分比 (0-100) |
| 6 | FreeHeap | u8 | 剩余堆内存百分比 (0-100) |

---

## 3.2 GET_INFO (0x01) — 获取设备信息

### 请求 (主机 → 设备)

载荷为空 (PayloadLen = 0)。

### 响应 (设备 → 主机)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | Status | u8 | 状态码 |
| 1-3 | FwVersion | u8[3] | 固件版本 (主.次.补丁) |
| 4-7 | SerialNum | u32 | 设备序列号 (32 位唯一标识) |
| 8-11 | ModelID | u8[4] | 设备型号标识 (4 字节 ASCII，如 "HXB1") |
| 12-13 | Capabilities | u16 | 支持的功能位图 |
| 14-15 | MaxPayload | u16 | 最大载荷长度 (固定 0x0800 = 2048) |
| 16 | ProtoVersion | u8 | 支持的协议版本号 |

### Capabilities 位图

| Bit | 功能 | 说明 |
|:---|:---|:---|
| 0 | CAN | CAN 总线支持 |
| 1 | CAN_FD | CAN FD 支持 |
| 2 | SPI | SPI 接口支持 |
| 3 | I2C | I2C 接口支持 |
| 4 | UART | UART 接口支持 |
| 5 | Reserved | 保留 |
| 6 | TCP | TCP 协议支持 |
| 7 | UDP | UDP 协议支持 |
| 8 | WebSocket | WebSocket 支持 |
| 9 | GPIO | GPIO 支持 |
| 10 | BULK | 批量传输支持 |
| 11 | OTA | OTA 固件升级支持 |
| 12 | WIFI_STA | 支持 Wi-Fi STA 配网命令 0x46–0x49；即使离线也置位 |
| 13-15 | — | 保留 |

---

## 3.3 GET_CONFIG (0x02) — 读取设备配置

读取设备的全局或模块级配置参数。

### 请求 (主机 → 设备)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | ConfigGroup | u8 | 配置组 (见下表) |
| 1 | ConfigKey | u8 | 配置项索引 (组内偏移) |

### ConfigGroup 定义

| 值 | 配置组 | 说明 |
|:---|:---|:---|
| 0x00 | 系统全局 | 设备名称、心跳间隔等 |
| 0x01 | CAN 默认 | CAN 模块默认参数 |
| 0x02 | SPI 默认 | SPI 模块默认参数 |
| 0x03 | I2C 默认 | I2C 模块默认参数 |
| 0x04 | UART 默认 | UART 模块默认参数 |
| 0x05 | 网络 | 网络模块默认参数 |
| 0x06 | GPIO | GPIO 模块默认参数 |

### 系统全局配置组 (0x00) 常用 ConfigKey 定义

| ConfigKey | 参数名称 | 数据类型 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| 0x01 | DeviceName | str | "HXB-Device" | 设备显示名称 |
| 0x02 | HeartbeatInterval | u16 | 5000 | 心跳上报间隔 (毫秒) |
| 0x03 | FlowControlEnable | u8 | 0x01 | 0x00 = 禁用设备端主动背压上报，0x01 = 启用流控。如果设为 0x00，设备端在缓冲区接近满时不会发送 `FLOW_CONTROL (0x05)` 帧。 |
| 0x10 | UartChannelCount | u8 | 1 | 当前配置启用的扩展 UART 通道数，关闭时为 0（只读） |
| 0x11 | CanChannelCount | u8 | 1 | 当前配置启用的 CAN/CAN-FD 通道数，关闭时为 0（只读） |
| 0x12 | McpBaudRate | u32 | 921600 | MCP 通信端口波特率。写入后需通过 RESET(0x00) 软复位使新波特率生效。有效范围: 9600 ~ 5000000。 |

> **注意**：修改 `McpBaudRate` 后设备会立即将新值写入 NVS 并返回 SUCCESS，但当前链路波特率不变。主机需在收到 SUCCESS 响应后发送 `RESET(0x00)` 软复位，设备重启后将使用新的波特率初始化 MCP 通信端口。

### 响应 (设备 → 主机)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | Status | u8 | 状态码 |
| 1 | ConfigGroup | u8 | 配置组 |
| 2 | ConfigKey | u8 | 配置项索引 |
| 3-4 | ValueLen | u16 | 值的长度 (V) |
| 5... | Value | u8[V] | 配置值 |

---

## 3.4 SET_CONFIG (0x03) — 写入设备配置

### 请求 (主机 → 设备)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | ConfigGroup | u8 | 配置组 |
| 1 | ConfigKey | u8 | 配置项索引 |
| 2-3 | ValueLen | u16 | 值的长度 (V) |
| 4... | Value | u8[V] | 新的配置值 |

### 响应 (设备 → 主机)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | Status | u8 | 状态码 |

---

## 3.5 RESET (0x04) — 复位

### 请求 (主机 → 设备)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | ResetType | u8 | 复位类型 |
| 1 | ChannelID | u8 | 通道号 (仅 ResetType=0x02 时有效) |

### ResetType 定义

| 值 | 含义 |
|:---|:---|
| 0x00 | 软复位（重新初始化所有模块） |
| 0x01 | 恢复出厂设置（清除所有配置） |
| 0x02 | 复位指定通道（不影响其他通道） |
| 0x03 | 硬件看门狗复位（强制重启） |

### 响应 (设备 → 主机)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | Status | u8 | 状态码 |

> **注意**：
> - 软复位和硬件复位后设备需要重新初始化，主机应等待设备发送 PING 响应后再发送其他命令。
> - **ResetType=0x00 (软复位)** 在调用 `esp_restart()` 前会依次执行各模块的 `stop()` 钩子（反向遍历注册顺序）。`stop()` 负责关闭所有 TCP/UDP/WS socket、停止后台 select 任务、清理网络连接资源，确保对端收到有序的 RST/FIN 而非静默断开。

---

## 3.6 FLOW_CONTROL (0x05) — 流量控制

用于防止缓冲区溢出。设备端缓冲区接近满时主动通知主机暂停发送。

### 设备 → 主机（背压通知）

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | Action | u8 | 流控动作 |
| 1 | ModuleID | u8 | 受影响的模块命令码前缀 (如 0x10 = CAN) |
| 2 | ChannelID | u8 | 受影响的通道 (0xFF = 所有通道) |
| 3-4 | BufferUsage | u16 | 缓冲区使用量（字节） |
| 5-6 | BufferCapacity | u16 | 缓冲区总容量（字节） |

### Action 定义

| 值 | 含义 | 说明 |
|:---|:---|:---|
| 0x00 | XOFF (暂停) | 主机应停止向该模块/通道发送数据 |
| 0x01 | XON (恢复) | 主机可以继续发送数据 |
| 0x02 | OVERFLOW (溢出) | 缓冲区已溢出，部分数据丢失 |

### 主机 → 设备（流控查询）

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | ModuleID | u8 | 查询的模块 (0xFF = 全部) |

### 查询响应 (设备 → 主机)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | Status | u8 | 状态码 |
| 1 | Count | u8 | 报告的模块数量 (N) |
| 2... | Reports | — | N 个模块的流控状态 (每个 5 字节) |

每个模块的流控状态：

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | ModuleID | u8 | 模块 ID |
| 1 | State | u8 | 0=正常, 1=暂停, 2=溢出 |
| 2-3 | BufferUsage | u16 | 缓冲区使用量 |
| 4 | BufferPercent | u8 | 使用百分比 (0-100) |

---

## 3.7 SYS_BOOT_EVENT (0x06) — 系统上电与复位主动上报

设备端上电启动完毕，或者在已打开物理连接的状态下发生软件复位/硬件看门狗复位后，主动向物理链路发送此事件帧，以便上位机感知并重建配置。

### 设备 → 主机主动上报

Flags: DIR=1, EVT=1, TS=1（推荐携带上电时的微秒时间戳）

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | ResetReason | u8 | 复位/启动原因（对应下表） |
| 1 | BootStatus | u8 | 启动状态（`0x00` = 正常启动，`0x01` = 从 OTA 回滚启动） |

### ResetReason 定义

| 值 | 重启原因 | 对应 ESP-IDF v6.0.1 常量及说明 |
|:---|:---|:---|
| `0x01` | POWERON_RESET | `ESP_RST_POWERON` — 物理上电复位 / VDD 重新建立 |
| `0x03` | SW_RESET | `ESP_RST_SW` — 通过 `esp_restart()` 软件触发的复位 |
| `0x05` | DEEPSLEEP_RESET | `ESP_RST_DEEPSLEEP` — 深度睡眠唤醒复位 |
| `0x06` | INT_WDT_RESET | `ESP_RST_INT_WDT` — 中断看门狗复位 |
| `0x07` | TASK_WDT_RESET | `ESP_RST_TASK_WDT` — 任务看门狗复位 |
| `0x08` | WDT_RESET | `ESP_RST_WDT` — 其他看门狗复位 |
| `0x0D` | BROWNOUT_RESET | `ESP_RST_BROWNOUT` — 欠压复位（电源供电不稳定） |
| `0x0E` | PANIC_RESET | `ESP_RST_PANIC` — 异常/Panic 复位 |
| `0xFF` | UNKNOWN | 未知复位原因 |

---

## 3.8 GET_TOPOLOGY (0x07) — 获取硬件拓扑

获取设备所有物理外设通道的静态拓扑信息，包括每个通道的唯一 ID 和硬件类型。
Host 应在建立连接、完成握手后首先发送此命令，以动态发现设备支持哪些外设通道，
避免硬编码通道号。

### 请求 (主机 → 设备)

载荷为空 (PayloadLen = 0)。

### 响应 (设备 → 主机)

| 偏移 | 字段 | 类型 | 说明 |
|:---|:---|:---|:---|
| 0 | Status | u8 | 状态码 |
| 1 | ChannelCount | u8 | 外设通道总数 (N) |
| 2 + i*2 | ChannelID | u8 | 第 i 个通道的静态唯一 ID |
| 3 + i*2 | DeviceType | u8 | 第 i 个通道的硬件类型 (见下表) |

其中 i ∈ [0, N-1]，响应总长度 = 2 + N * 2 字节。

### DeviceType 定义

| 值 | 类型 | 说明 |
|:---|:---|:---|
| `0x01` | UART | 扩展串口 |
| `0x02` | CAN | CAN / CAN FD 总线 |
| `0x03` | SPI | SPI 总线（每个 CS 片选为一个独立通道） |
| `0x04` | I2C | I2C 总线 |
| `0x05` | GPIO | GPIO 引脚组 |

### 静态 Channel ID 分配原则

所有 Channel ID 由固件在编译期静态分配，Host 不得自行编造。
Host 必须使用 GET_TOPOLOGY 返回的 Channel ID 来寻址后续的 Open/Config/Send 等操作。

预期首次连接流程变更为：

```
1. PING (0x00)       — 确认物理链路可用
2. GET_INFO (0x01)   — 识别设备身份与协议版本
3. GET_TOPOLOGY (0x07) — 获取通道拓扑
4. 根据拓扑结果，对目标通道发送 OPEN 等操作
```

> **注意**：如果 Host 使用了一个不在拓扑表中的非法 Channel ID 发起 Open/Config，
> 设备将返回 `ERR_CHANNEL_INVALID (0x0A)`。如果 Channel ID 存在但硬件类型与
> 命令模块不匹配（如用 UART 命令打开 CAN 通道），设备将返回 `ERR_TYPE_MISMATCH (0x16)`。

